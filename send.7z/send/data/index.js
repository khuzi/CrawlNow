export const signupData = [
  { name: "Name", placehlder: "What's your name?" },
  { name: "Email", placehlder: "What's your email address?" },
  { name: "Password", placehlder: "Enter a password" },
];

export const loginData = [
  { name: "Email Address", placehlder: "What's your email?" },
  { name: "Password", placehlder: "Enter your password" },
];
