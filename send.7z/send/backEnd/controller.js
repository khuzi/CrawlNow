import { UserProvider } from "../utils/user";

const controller = (sub) => {
  if (sub === "google-oauth2|105055357399766626124") {
    // use the data inside file 1
  } else if (user.name === "email2") {
    // use the data inside file 2
  }
};
